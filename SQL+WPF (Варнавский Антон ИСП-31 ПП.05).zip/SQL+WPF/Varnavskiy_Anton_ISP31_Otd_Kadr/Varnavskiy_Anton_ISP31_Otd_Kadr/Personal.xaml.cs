﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Varnavskiy_Anton_ISP31_Otd_Kadr
{
    /// <summary>
    /// Логика взаимодействия для Personal.xaml
    /// </summary>
    public partial class Personal : Page
    {
        public Personal()
        {
            InitializeComponent();
        }

        private void Dep1_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Dep1());
        }

        private void Dep2_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Dep2());
        }

        private void Dep3_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Dep3());
        }
    }
}
