﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Varnavskiy_PP05_Otd_Kadr
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Следующий_Click(object sender, RoutedEventArgs e)
        {
            int next = Phone.SelectedIndex + 1;
            if (next >= Phone.Items.Count)
                next = 0;
            Phone.SelectedIndex = next;
        }

        private void Предыдущий_Click(object sender, RoutedEventArgs e)
        {
            int previous = Phone.SelectedIndex - 1;
            if (previous < 0)
                previous = Phone.Items.Count - 1;
            Phone.SelectedIndex = previous;
        }
    }
}
